#
# Splunk Powershell Resource Kit Demo
#
# Loading the Module
#
Import-Module c:\data\demo\Splunk
#
# Disabling certificate checking
#
Disable-CertificateValidation
#
# Lets start by importing our conenction object.
#
Import-SplunkConnectionObject -Path c:\Data\Demo\MyConnectionObject.xml -force 
#
# Lets start with dealing with licensefiles
#
# What License files do I have?
#
Get-SplunkLicenseFile
#
# How do I add a license file?
#
Add-SplunkLicenseFile -Name MyLicense -Path C:\Data\Demo\MyLicenseFile.License
#
# How do I remove a license file?
#
Remove-SplunkLicenseFile -HASH "<HASH>"
#
# To view the License Stack
#
Get-SplunkLicenseStack
#
# To view the license groups
#
Get-SplunkLicenseGroup
#
# To activate (Enable) a specific license group. CAREFUL!!!
#
Enable-SplunkLicenseGroup -GroupName Enterprise
#
# Get the License Pools
#
Get-SplunkLicensePool
#
# To add a License Pool
#
Add-SplunkLicensePool -PoolName MyPool -Quota 1gb -StackID enterprise
Get-SplunkLicensePool
#
# To Change a License Pool
#
Set-SplunkLicensePool -PoolName MyPool -Quota 2gb -Force
#
# To Remove a License Pool
#
Remove-SplunkLicensePool -PoolName MyPool -Force
#
# To see license messages
#
Get-SplunkLicenseMessage -ComputerName Goose
#
# To See the License Master
#
Get-SplunkLicenseMaster
#
# To set the License Master 
#
Set-SplunkLicenseMaster -ComputerName Win-dev-2 -Force
#
# To list license slaves
#
Get-SplunkLicenseSlave
