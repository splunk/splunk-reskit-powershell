#
# Splunk Powershell Resource Kit Demo
#
# Loading the Module
#
Import-Module c:\data\Demo\Splunk
#
# Disabling certificate checking
#
Disable-CertificateValidation
# 
# Here are the authentication cmdlets
#
# Creates a Connection object for the Splunk Resource Kit to use for defaults.
#
Connect-Splunk -ComputerName localhost -UserName admin
#
# Returns Splunk users
#
Get-SplunkdUser
#
# Creates a New user
#
New-SplunkdUser -UserName RemoveMe -DefaultApp search  -email RemoveM@splunk.com -Password changeme
#
# Ooopps... we messed up the email. Use Set-SplunkdUser to change it.
#
Set-SplunkdUser -UserName RemoveMe -email RemoveMe@splunk.com
#
# We don't like the default password use this to set a new user password
#
Set-SplunkdPassword -UserName RemoveMe 
#
# Now we can remove the user with Remove-SplunkdUser
#
Remove-SplunkdUser -UserName RemoveMe
#
# Returns the currently logged in users
#
Get-SplunkLogin
#
# This returns a Splunk Auth token to be used for authenticating to the REST endpoint. 
#
Get-SplunkAuthToken -UserName admin
#
# What if I want to autoconnect to my Splunk indexer when I open PowerShell?  
#
# You can use this export command to export the current connection object to a file. 
#
Export-SplunkConnectionObject -Path c:\Data\Demo\MyConnectionObject.xml -force
#
# Great... you have a file now how do you use it?
#
Import-SplunkConnectionObject -Path c:\Data\Demo\MyConnectionObject.xml -force

