#
# Splunk Powershell Resource Kit Demo
#
# Loading the Module
#
Import-Module c:\data\demo\Splunk
#
# Disabling certificate checking
#
Disable-CertificateValidation
#
# Lets start with what cmdlets we have so far.
#
Get-Splunk
#
# Lets take a look at Get-Splunkd
#
$MyCreds = Get-Credential
Get-Splunkd -ComputerName localhost -port 8089 -Protocol https -timeout 5000 -Credential $MyCreds
#
# Having to pass parameters everytime we want to use a cmdlet can be a pain. 
# So we included Connect-Splunk to allow you to set default values.
#
Connect-Splunk -ComputerName localhost -UserName admin
Get-SplunkConnectionObject
#
# Now we can do this instead
#
Get-Splunkd
#
# If the admin account has the same password on multiple splunk instances you can do this.
#
#
$SplunkServers = "Server1","Server2"
$SplunkServers | Get-Splunkd
#
# Lets use Set-Splunkd to change the session timeout
#
Set-Splunkd -SessionTimeout 1d 
#
# We can also to this on a set of servers
#
$SplunkServers | Set-Splunkd -SessionTimeout 1h -force
#
# After we make these kind of changes we need to restart splunkd
#
Restart-SplunkService -wait
#
# As with the others we can also do this in mass
#
$SplunkServers | Restart-SplunkService -force 

