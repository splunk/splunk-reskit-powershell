﻿#
# Splunk Powershell Resource Kit Demo
#
# Loading the Module
#
Import-Module c:\data\demo\Splunk
#
# Disabling certificate checking
#
Disable-CertificateValidation
#
# Lets start by importing our conenction object.
#
Import-SplunkConnectionObject -Path c:\Data\Demo\MyConnectionObject.xml -force 
#
# To See all the server classes defined
#
Get-SplunkServerClass
#
# To create a new server class
#
New-SplunkServerClass -ServerClass RemoveMe -Whitelist "1.1.1.1","2.2.2.2","3.3.3.3"
#
# Oh... Meant to make that a blacklist. We can use Set-SplunkServerClass
#
Set-SplunkServerClass -ServerClass RemoveMe -blacklist "1.1.1.1","2.2.2.2","3.3.3.3" -whitelist $null
#
# To disable a server class
#
Disable-SplunkServerClass -ServerClass RemoveMe
#
# To enable a server class
#
Enable-SplunkServerClass -ServerClass RemoveMe
#
# To return all the deployment clients connected to the deployment server
#
Get-SplunkDeploymentClient
#
# To reload deployment config (without restart)
#
Invoke-SplunkDeploymentServerReload
